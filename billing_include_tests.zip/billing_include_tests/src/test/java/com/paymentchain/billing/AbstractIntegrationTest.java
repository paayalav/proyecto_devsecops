package com.paymentchain.billing;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;




@ExtendWith(MockitoExtension.class)
public abstract class AbstractIntegrationTest {
   

}
